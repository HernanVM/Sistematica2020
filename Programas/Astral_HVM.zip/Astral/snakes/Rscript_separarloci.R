setwd("~/Desktop/beast2")
library(ape)
snakes <- read.dna("data-snakesMLseptax.fasta", format="fasta")
ATP <- snakes[,1:665]
CBA <- snakes[,666:1190]
CL11 <- snakes[,1191-1610]
CL51A <- snakes[,1611-1870]
GAPD <- snakes[,1871-2130]
LAM <- snakes[,2131-2814]
TBP <- snakes[,2815-3610]
aclone <- snakes[,3611-3906]
cl1f <- snakes[,3907-4126]
cl25 <- snakes[,4127-4388]
cl31 <- snakes[,4389-4644]
cl61 <- snakes[,4645-4838]
ef <- snakes[,4839-5285]
est2a1 <- snakes[,5286-6134]
fgb <- snakes[,6135-6932]
od <- snakes[,6933-7454]
ausnp4 <- snakes[,7455-7721]
cl41 <- snakes[,7722-7995]
cl63 <- snakes[,7996-8466]

#sCON <- cbind(sND2,sCOI,s204,sGAP,sTGF,sMUS)
#write.dna(sCON, "TsinaCON.fasta", format="fasta")

write.FASTA(ATP, "data-snakesATP.fasta")
write.FASTA(CBA, "data-snakesCBA.fasta")
write.FASTA(CL11, "data-snakesCL11.fasta")
write.FASTA(CL51A, "data-snakesCL51A.fasta")
write.FASTA(GAPD, "data-snakesGAPD.fasta")
write.FASTA(LAM, "data-snakesLAM.fasta")
write.FASTA(TBP, "data-snakesTBP.fasta")
write.FASTA(aclone, "data-snakesaclone.fasta")
write.FASTA(cl1f, "data-snakescl1f.fasta")
write.FASTA(cl25, "data-snakescl25.fasta")
write.FASTA(cl31, "data-snakescl31.fasta")
write.FASTA(cl61, "data-snakescl61.fasta")
write.FASTA(ef, "data-snakesef.fasta")
write.FASTA(est2a1, "data-snakesest2a1.fasta")
write.FASTA(fgb, "data-snakesfgb.fasta")
write.FASTA(od, "data-snakesod.fasta")
write.FASTA(ausnp4, "data-snakesausnp4.fasta")
write.FASTA(cl41, "data-snakescl41.fasta")
write.FASTA(cl63, "data-snakescl63.fasta")







